import javax.crypto.KeyGenerator;

public class AES extends Algorithm {
    Key key;
}

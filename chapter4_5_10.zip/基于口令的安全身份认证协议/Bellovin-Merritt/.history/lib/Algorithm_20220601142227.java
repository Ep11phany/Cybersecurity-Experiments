import javax.crpyto.Cipher;


public abstract class Algorithm {
    
}

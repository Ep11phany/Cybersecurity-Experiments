public class DES extends Algorithm {
    Key key;
}

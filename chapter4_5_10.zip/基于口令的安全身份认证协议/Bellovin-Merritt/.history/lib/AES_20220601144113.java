import javax.crypto.KeyGenerator;
import java.security.Key;

public class AES extends Algorithm {
    Key key;
}

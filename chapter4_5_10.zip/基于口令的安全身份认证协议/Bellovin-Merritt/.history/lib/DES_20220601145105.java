public class DES extends Algorithm {
    
}

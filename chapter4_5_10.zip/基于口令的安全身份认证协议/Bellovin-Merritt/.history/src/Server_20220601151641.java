public class Server extends Thread {
    
}

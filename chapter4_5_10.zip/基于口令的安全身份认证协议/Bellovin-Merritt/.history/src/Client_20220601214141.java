

// Client should be acted as A

public class Client extends Thread {
    String pw = "Ep1phanyFillTo16";
}

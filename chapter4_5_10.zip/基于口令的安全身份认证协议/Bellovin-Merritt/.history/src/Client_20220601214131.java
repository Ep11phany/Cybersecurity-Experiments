

// Client should be acted as A

public class Client extends Thread {
    
}
